/**
 * A Campus consists of multiple dorms and guests checking In and Out.
 * @author Arshdeep Singh, Mayur Jartarkar
 * @version August 20, 2019
*/
public class Campus {

}
