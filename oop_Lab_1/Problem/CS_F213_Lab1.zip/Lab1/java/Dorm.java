/**
 * A dorm is a part of a Campus.
 * @author Arshdeep Singh, Mayur Jartarkar
 * @version August 20, 2019
*/
public class Dorm {

}
